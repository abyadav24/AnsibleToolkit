#!/usr/bin/expect -f

# Define variables (Replace with actual values or pass as arguments)
set ip "172.25.57.42"
set username "ADMIN1"
set password "Hitachi1"
set timeout 20

# Start the IPMI SOL session
spawn ipmitool -I lanplus -H $ip -U $username -P $password sol activate

# Wait for the SOL session to become operational
expect {
    "SOL Session operational" { send "\r" }
    timeout { puts "Failed to activate SOL session"; exit 1 }
}

# Small delay to ensure the session is stable
sleep 2

# Handle Ubuntu login prompt
expect {
    "ubuntu login:" {
        send "ubuntu\r"
        exp_continue
    }
    "Password:" {
        send "\r"
    }
}

# Run the script once after logging in
expect "$ " {
        #send "sh /home/ubuntu/flash-X710-T4L_for_OCP_3.0.sh\r"  update below all will works <----------
	
	#send "sh /cdrom/firmware/flash-X710-T4L_for_OCP_3.0.sh\r"
	# Navigate to the correct directory
	send "cd /cdrom/smci\r"
	expect "$ "

	# Copy and set permissions
	send "sudo cp -rp AOC-A25G-M2SM /tmp\r"
	expect "$ "
	send "sudo chmod -R +x /tmp/AOC-A25G-M2SM/\r"
	expect "$ "

	# Unzip files
	send "sudo unzip /tmp/AOC-A25G-M2SM/*.zip -d /tmp/AOC-A25G-M2SM/\r"
	expect "$ "

	# Find the FWUpdate.sh script
	send "find /tmp/AOC-A25G-M2SM/ -name FWUpdate.sh\r"
	expect {
    	   -re {(/.*FWUpdate\.sh)} {
               set FWUpdate $expect_out(1,string)
               send "sudo $FWUpdate\r"
    	   }
    	   timeout {
               puts "Failed to locate FWUpdate.sh"; exit 1
    	   }
	}

 	send "sudo ./"$FWUpdate" "
}

# Wait for the script to finish executing (adjust time if needed)
sleep 180

# Exit the SOL session using the escape sequence (~.)
send "~.\r"

# Ensure EOF handling
expect eof

