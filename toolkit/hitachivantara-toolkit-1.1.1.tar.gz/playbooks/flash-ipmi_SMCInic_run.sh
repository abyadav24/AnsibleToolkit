#!/usr/bin/expect -f

# Define variables (Replace with actual values or pass as arguments)
set ip "172.25.57.43"
set username "ADMIN1"
set password "cmb9.admin"
set timeout 20

# Start the IPMI SOL session
spawn ipmitool -I lanplus -H $ip -U $username -P $password sol activate

# Wait for the SOL session to become operational
expect {
    "SOL Session operational" { send "\r" }
    timeout { puts "Failed to activate SOL session"; exit 1 }
}

# Small delay to ensure the session is stable
sleep 2

# Handle Ubuntu login prompt
expect {
    "ubuntu login:" {
        send "ubuntu\r"
        exp_continue
    }
    "Password:" {
        send "\r"
    }
}

# Run the script once after logging in
expect "$ " {
        #send "sh /home/ubuntu/flash-X710-T4L_for_OCP_3.0.sh\r"  update below all will works <----------
	#send "sh /cdrom/firmware/flash-X710-T4L_for_OCP_3.0.sh\r"
 	send "sh /cdrom/smci/flash-SMCInic-AOC-A25G-M2SM.sh\r"
}

# Wait for the script to finish executing (adjust time if needed)
sleep 180

# Exit the SOL session using the escape sequence (~.)
send "~.\r"

# Ensure EOF handling
expect eof

